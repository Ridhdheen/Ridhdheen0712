import java.util.*;
public class p1{
    public static double SI(double p,double r,double t){
        return (p*r*t/100);
    }
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("enter p,r,t");
        double p=sc.nextDouble();
        double r=sc.nextDouble();
        double t=sc.nextDouble();
        System.out.println("SI = " + SI(p,r,t));
    }
}