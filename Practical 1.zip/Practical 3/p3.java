import java.util.*;
public class p3{
    public static double area(double r){
        return 3.14*r*r;
    }
    public static double area(double h,double b){
        return 0.5*h*b;
    }
    public static float area(float a){
        return a*a;
    }
    public static void main(String[] args){
    }
}