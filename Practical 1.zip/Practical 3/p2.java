import java.util.*;
public class p2{
    public static void max(int a,int b,int c){
         if(a>b && a>c){
            System.out.println("a is maximum");
         }
         else if(b>c){
            System.out.println("b is maximum");
            }
            else{
                System.out.println("c is maximum");
            }
        }
    public static void main(String[] args){
        int n1=1,n2=2,n3=10;
        max(n1,n2,n3);
    }
}
