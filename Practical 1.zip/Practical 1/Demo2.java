import java.util.*;
public class Demo2{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("enter 1 no");
        int a = sc.nextInt();
        System.out.println("enter 2 no");
        int b = sc.nextInt();
        a=a+b;
        System.out.println(a);
        
    }
}