public class Demo{
    public static void main(String[] args){
        System.out.println("hello  java");
        System.out.println("abc\nabc\nabc");
    }
}