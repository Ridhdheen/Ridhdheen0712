import java.util.*;
public class Demo3{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("enter 1 number");
        double a = sc.nextDouble();
        a = a*3.28084;
        System.out.println(a);
    }
}