import java.util.Scanner;
public class p3 {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int r=sc.nextInt(),int r=sc.nextInt();
        int[][] arr=new int[r][c];
        for(int i=0;i<arr.lentgh;i++)
        {
            for(int j=0;j<arr.lenth;j++){
                arr[i][j]=sc.nextInt();
            }
        }
        for(int i=0;i<r;i++)
        {
            for(int ij=0;j<r;j++)
            {
                System.out.println();
            }
        }
    }

} 