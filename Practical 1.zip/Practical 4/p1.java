import java.util.*;
public class p1{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("enter size of array");
        int n=sc.nextInt();
        int[] array=new int[n];
        for(int i=0;i<n;i++){
            System.out.println("enter"+i+"element");
            array[i]=sc.nextInt();
        }
        for(int i=0;i<n;i++){
            System.out.println(array[i]);
        }

    }
}