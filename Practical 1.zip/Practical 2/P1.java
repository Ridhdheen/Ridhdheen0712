import java.util.*;
public class P1{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner (System.in);
        System.out.println("enter area of circle");
        double a = sc.nextDouble();
        double r = Math.sqrt(a/3.14);
        double d = 2*r;
        System.out.println(d);
    }
}